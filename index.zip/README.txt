The images folder contains all the images used and the results, along with the stored correspondance points.

The main.py contains all the code for part A. 